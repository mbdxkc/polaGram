# Polagram Icon Pack

This package contains all necessary icon files and social media assets for your website.

## Files Included

### Favicons
- favicon.ico (multi-size: 16x16, 32x32, 48x48)
- favicon-16x16.png
- favicon-32x32.png
- favicon-48x48.png

### Apple Touch Icons
- apple-touch-icon.png (180x180 - default)
- apple-touch-icon-57x57.png through apple-touch-icon-180x180.png (all standard sizes)

### Android/Chrome
- android-chrome-192x192.png
- android-chrome-512x512.png
- site.webmanifest (PWA manifest file)

### Microsoft Tiles
- mstile-70x70.png through mstile-310x310.png
- browserconfig.xml (Microsoft configuration)

### Social Media / Open Graph
- og.png (1200x630 - standard Open Graph)
- og-square.png (1200x1200 - square variant)
- twitter-card.png (1200x675)
- linkedin-share.png (1200x627)
- facebook-share.png (1200x630)

## Installation

1. Upload all PNG and ICO files to your website's root directory (or /assets/icons/)
2. Upload site.webmanifest and browserconfig.xml to your root directory
3. Copy the contents of html-head-snippet.html into your website's <head> section
4. Update the meta tags with your actual content (title, description, URL)

## Customization

Edit these files to match your needs:
- site.webmanifest: Update name, theme colors
- browserconfig.xml: Update TileColor if needed
- html-head-snippet.html: Update meta descriptions and URLs

## Notes

- All icons use transparent backgrounds where appropriate
- Social media images use black backgrounds to match your brand
- Icons are optimized for web use
- The favicon.ico contains multiple sizes for maximum compatibility

## Quick Start

For basic favicon support, at minimum include:
```html
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
```

For full cross-platform support, use the complete snippet from html-head-snippet.html.
